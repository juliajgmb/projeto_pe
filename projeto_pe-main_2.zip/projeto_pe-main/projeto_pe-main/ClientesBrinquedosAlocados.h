#pragma once

void BrinquedosAlocadosClientes(tRegistroCliente clientes[], int clientesRegistrados);
